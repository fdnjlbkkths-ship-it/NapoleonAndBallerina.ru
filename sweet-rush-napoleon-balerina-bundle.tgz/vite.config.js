import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import { defineConfig, loadEnv } from 'vite';
import { adminApiPlugin } from './scripts/vite-admin-plugin.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoName = process.env.GITHUB_REPOSITORY?.split('/')[1];
const base =
  process.env.GITHUB_ACTIONS && repoName ? `/${repoName}/` : '/';

const WORKER_ORDER_ORIGIN = 'https://napoleon-order-bot.napoleonorders.workers.dev';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  if (env.ADMIN_PIN && !process.env.ADMIN_PIN) process.env.ADMIN_PIN = env.ADMIN_PIN;
  if (env.VITE_ADMIN_PIN && !process.env.VITE_ADMIN_PIN) {
    process.env.VITE_ADMIN_PIN = env.VITE_ADMIN_PIN;
  }

  return {
    base,
    plugins: [adminApiPlugin()],
    server: {
      watch: {
        ignored: [
          '**/public/fonts/cerca-preview/**',
          '**/src/data/products.json.bak',
        ],
      },
      proxy: {
        '/api/order': {
          target: WORKER_ORDER_ORIGIN,
          changeOrigin: true,
          rewrite: () => '/order',
        },
      },
    },
    build: {
      rollupOptions: {
        input: {
          main: resolve(__dirname, 'index.html'),
          menu: resolve(__dirname, 'menu.html'),
          product: resolve(__dirname, 'product.html'),
          about: resolve(__dirname, 'about.html'),
          contacts: resolve(__dirname, 'contacts.html'),
          privacy: resolve(__dirname, 'privacy.html'),
          offer: resolve(__dirname, 'offer.html'),
          requisites: resolve(__dirname, 'requisites.html'),
          checkout: resolve(__dirname, 'checkout.html'),
          game: resolve(__dirname, 'game.html'),
          // admin.html intentionally omitted from production build
        },
      },
    },
  };
});
